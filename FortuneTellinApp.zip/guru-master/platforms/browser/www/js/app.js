 var count = 0
        $( ".container" ).click(function() {
        var words = ["Yes", 'No you will not', 'It will be great', "Maybe", "Maybe, somday", "Ask me again", "I have no idea", "Absolutley not","Tomorrow","Later","In the future","No","Someday","Let me check","OMG, yess!","LMAO","Yesss!","You are going to be beautiful","You will be handsome","Hmm, ask me again","I didn't hear you, speak louder","What do you think","What do you mean","Be careful","You will be homeless","How about NO!","I don't care","Nevermind","You will be a millionaire","You will be rich","You will win the lottery","You are going to die","You will get sick","Visa liberalisation will happen in 2025"];

            var item = words[Math.floor(Math.random()*words.length)];
            navigator.vibrate(3000);
            setTimeout(function(){
                $("#message").html('<h1>' + item + '</h1>');

            },3000); 
            
        });